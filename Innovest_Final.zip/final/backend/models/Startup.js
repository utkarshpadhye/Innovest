const mongoose = require("mongoose");

const startupSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    closingDate: { type: Date, required: true },
    totalInvestment: { type: Number, required: true },
    percentageDilution: { type: Number, required: true },
    document: {
      data: Buffer,
      contentType: String,
      name: String,
    },
    fundingRaised: { type: Number, default: 0 },
    investments: [
      {
        investor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        amount: Number,
        date: { type: Date, default: Date.now },
      },
    ],
  },
  { collection: "startups" }
);

module.exports = mongoose.model("Startup", startupSchema);
