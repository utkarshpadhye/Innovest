const mongoose = require("mongoose");

const investorSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    investments: [{ type: mongoose.Schema.Types.ObjectId, ref: "Startup" }],
  },
  { collection: "investors" }
); // Specify the collection name explicitly

module.exports = mongoose.model("Investor", investorSchema);
