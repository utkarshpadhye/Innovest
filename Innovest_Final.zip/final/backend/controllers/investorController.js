const Investor = require("../models/Investor");
const Startup = require("../models/Startup");

// Fetch investor profile
exports.getInvestorProfile = async (req, res) => {
  try {
    const investor = await Investor.findOne({ user: req.user._id }).populate(
      "investments"
    );
    if (!investor) {
      return res.status(404).json({ message: "Investor profile not found" });
    }
    res.json(investor);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Explore available startups
exports.exploreStartups = async (req, res) => {
  try {
    const startups = await Startup.find();
    res.json(startups);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Add investment to a startup
exports.investInStartup = async (req, res) => {
  const { startupId } = req.body;
  try {
    const investor = await Investor.findOne({ user: req.user._id });
    const startup = await Startup.findById(startupId);

    if (!startup) {
      return res.status(404).json({ message: "Startup not found" });
    }

    investor.investments.push(startup._id);
    await investor.save();

    res.json({ message: "Investment added successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

exports.getInvestments = async (req, res) => {
  try {
    const investor = await Investor.findOne({ user: req.user._id }).populate({
      path: "investments",
      select: "name description fundingGoal fundingRaised", // add any other fields you want
    });

    if (!investor) {
      return res.status(404).json({ message: "Investor not found" });
    }

    res.json(investor.investments);
  } catch (error) {
    console.error("Error fetching investments:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
