const Startup = require("../models/Startup");
const multer = require("multer");

// Configure multer for temporary storage
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
}).single("document");

exports.getProfile = async (req, res) => {
  try {
    const startup = await Startup.findOne({ user: req.user._id });
    if (!startup) {
      return res.status(404).json({ message: "Startup profile not found" });
    }
    res.json(startup);
  } catch (error) {
    console.error("Profile retrieval error:", error);
    res.status(500).json({
      message: "Error retrieving profile",
      error: error.message,
    });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const startup = await Startup.findOneAndUpdate(
      { user: req.user._id },
      { $set: req.body },
      { new: true, runValidators: true }
    );

    if (!startup) {
      return res.status(404).json({ message: "Startup profile not found" });
    }

    res.json(startup);
  } catch (error) {
    console.error("Profile update error:", error);
    res.status(500).json({
      message: "Error updating profile",
      error: error.message,
    });
  }
};

exports.uploadDocument = async (req, res) => {
  try {
    upload(req, res, async (err) => {
      if (err) {
        console.error("Upload error:", err);
        return res.status(400).json({
          message: err.message || "Error uploading document",
        });
      }

      if (!req.file) {
        return res.status(400).json({
          message: "Please upload a PDF file",
        });
      }

      try {
        const startup = await Startup.findOne({ user: req.user._id });
        if (!startup) {
          return res.status(404).json({ message: "Startup not found" });
        }

        startup.document = {
          data: req.file.buffer,
          contentType: req.file.mimetype,
          name: req.file.originalname,
        };

        await startup.save();

        res.json({
          message: "Document uploaded successfully",
          documentName: req.file.originalname,
        });
      } catch (error) {
        console.error("Database error:", error);
        res.status(500).json({
          message: "Error saving document to database",
          error: error.message,
        });
      }
    });
  } catch (error) {
    console.error("Controller error:", error);
    res.status(500).json({
      message: "Server error during upload",
      error: error.message,
    });
  }
};

exports.getDocument = async (req, res) => {
  try {
    const startup = await Startup.findById(req.params.id);
    if (!startup || !startup.document) {
      return res.status(404).json({ message: "Document not found" });
    }

    res.set("Content-Type", startup.document.contentType);
    res.set(
      "Content-Disposition",
      `inline; filename="${startup.document.name}"`
    );

    res.send(startup.document.data);
  } catch (error) {
    console.error("Document retrieval error:", error);
    res.status(500).json({
      message: "Error retrieving document",
      error: error.message,
    });
  }
};

exports.investInStartup = async (req, res) => {
  try {
    const startup = await Startup.findById(req.params.id);
    if (!startup) {
      return res.status(404).json({ message: "Startup not found" });
    }

    const investment = {
      investor: req.user._id,
      amount: req.body.amount,
      date: new Date(),
    };

    startup.investments.push(investment);
    startup.fundingRaised += req.body.amount;

    await startup.save();
    res.json({
      message: "Investment recorded successfully",
      startup,
    });
  } catch (error) {
    console.error("Investment error:", error);
    res.status(500).json({
      message: "Error processing investment",
      error: error.message,
    });
  }
};

exports.updateProgress = async (req, res) => {
  try {
    const startup = await Startup.findOneAndUpdate(
      { user: req.user._id },
      { $set: { fundingRaised: req.body.fundingRaised } },
      { new: true }
    );

    if (!startup) {
      return res.status(404).json({ message: "Startup not found" });
    }

    res.json({
      message: "Progress updated successfully",
      startup,
    });
  } catch (error) {
    console.error("Progress update error:", error);
    res.status(500).json({
      message: "Error updating progress",
      error: error.message,
    });
  }
};
