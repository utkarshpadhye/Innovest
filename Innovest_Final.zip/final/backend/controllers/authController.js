const User = require("../models/User");
const Investor = require("../models/Investor");
const Startup = require("../models/Startup");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

// Helper function to generate JWT
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "1h" });
};

// Validate password strength
const isPasswordStrong = (password) => {
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  return (
    password.length >= minLength &&
    hasUpperCase &&
    hasLowerCase &&
    hasNumbers &&
    hasSpecialChar
  );
};

// Register Investor
exports.registerInvestor = async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;

    // Validate input
    if (!firstName || !lastName || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }

    // Check password strength
    if (!isPasswordStrong(password)) {
      return res.status(400).json({
        message:
          "Password must be at least 8 characters long and contain uppercase, lowercase, numbers, and special characters",
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // Create user
    const user = await User.create({
      email,
      password,
      role: "Investor",
    });

    // Create investor profile
    await Investor.create({
      user: user._id,
      firstName,
      lastName,
    });

    res.status(201).json({ message: "Registration successful" });
  } catch (error) {
    console.error("Investor registration error:", error);
    res.status(500).json({ message: "Server error during registration" });
  }
};

// Register Startup
exports.registerStartup = async (req, res) => {
  try {
    const {
      startupName,
      email,
      password,
      description,
      totalInvestment,
      percentageDilution,
      closingDate,
    } = req.body;

    // Validate input
    if (
      !startupName ||
      !email ||
      !password ||
      !description ||
      !totalInvestment ||
      !percentageDilution ||
      !closingDate
    ) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }

    // Check password strength
    if (!isPasswordStrong(password)) {
      return res.status(400).json({
        message:
          "Password must be at least 8 characters long and contain uppercase, lowercase, numbers, and special characters",
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // Create user
    const user = await User.create({
      email,
      password,
      role: "Startup",
    });

    // Create startup profile
    await Startup.create({
      user: user._id,
      title: startupName,
      description,
      totalInvestment: Number(totalInvestment),
      percentageDilution: Number(percentageDilution),
      closingDate: new Date(closingDate),
    });

    res.status(201).json({ message: "Registration successful" });
  } catch (error) {
    console.error("Startup registration error:", error);
    res.status(500).json({ message: "Server error during registration" });
  }
};

// Login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Check password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Generate token
    const token = generateToken(user._id);

    // Get additional profile data
    let profile;
    if (user.role === "Investor") {
      profile = await Investor.findOne({ user: user._id });
    } else {
      profile = await Startup.findOne({ user: user._id });
    }

    res.json({
      token,
      role: user.role,
      profile: {
        email: user.email,
        ...profile.toObject(),
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error during login" });
  }
};

// Verify Token
exports.verifyToken = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
      return res.status(401).json({ message: "Invalid token" });
    }

    res.json({ user });
  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }
};
