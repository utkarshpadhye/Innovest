const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const {
  getInvestorProfile,
  exploreStartups,
  investInStartup,
  getInvestments,
} = require("../controllers/investorController");

const router = express.Router();

router.get("/profile", protect, getInvestorProfile);
router.get("/investments", protect, getInvestments); // New route
router.get("/explore", protect, exploreStartups);
router.post("/invest", protect, investInStartup);

module.exports = router;
