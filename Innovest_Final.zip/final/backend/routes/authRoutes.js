const express = require("express");
const {
  registerInvestor,
  registerStartup,
  login,
  verifyToken,
} = require("../controllers/authController");
const router = express.Router();

router.post("/register/investor", registerInvestor);
router.post("/register/startup", registerStartup);
router.post("/login", login);
router.get("/verify", verifyToken);

module.exports = router;
