const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const {
  getProfile,
  updateProfile,
  uploadDocument,
  getDocument,
  investInStartup,
  updateProgress,
} = require("../controllers/startupController");

const router = express.Router();

// Profile routes
router.get("/profile", protect, getProfile);
router.post("/update-profile", protect, updateProfile);

// Document routes
router.post("/upload-document", protect, uploadDocument);
router.get("/:id/document", protect, getDocument);

// Investment routes
router.post("/:id/invest", protect, investInStartup);
router.post("/update-progress", protect, updateProgress);

module.exports = router;
