const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const path = require("path");
const User = require("../models/User");
const Investor = require("../models/Investor");
const Startup = require("../models/Startup");

require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

async function seedDatabase() {
  try {
    console.log("Attempting to connect to MongoDB...");

    if (!process.env.MONGO_URI) {
      throw new Error("MONGO_URI is not defined in environment variables");
    }

    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to MongoDB successfully");

    // Clear existing data
    await User.deleteMany({});
    await Investor.deleteMany({});
    await Startup.deleteMany({});

    // Create a regular user first to let the User model's pre-save middleware handle the password hashing
    const investorUser = new User({
      email: "test.investor@example.com",
      password: "test123", // This will be hashed by the User model's pre-save middleware
      role: "Investor",
    });
    await investorUser.save();

    const startup1User = new User({
      email: "startup1@example.com",
      password: "test123",
      role: "Startup",
    });
    await startup1User.save();

    const startup2User = new User({
      email: "startup2@example.com",
      password: "test123",
      role: "Startup",
    });
    await startup2User.save();

    const startup3User = new User({
      email: "startup3@example.com",
      password: "test123",
      role: "Startup",
    });
    await startup3User.save();

    console.log("Created test users successfully");

    // Create test startups
    const startups = await Startup.create([
      {
        user: startup1User._id,
        title: "Tech Innovators AI",
        description:
          "AI-driven solutions for healthcare using cutting-edge machine learning algorithms to improve patient diagnostics and treatment recommendations.",
        closingDate: new Date("2024-12-31"),
        totalInvestment: 500000,
        percentageDilution: 15,
        documents: "https://example.com/docs/tech-innovators",
      },
      {
        user: startup2User._id,
        title: "Green Energy Solutions",
        description:
          "Revolutionary solar panel technology that increases energy efficiency by 40% while reducing manufacturing costs by 30%.",
        closingDate: new Date("2024-11-30"),
        totalInvestment: 750000,
        percentageDilution: 20,
        documents: "https://example.com/docs/green-energy",
      },
      {
        user: startup3User._id,
        title: "FinTech Revolution",
        description:
          "Blockchain-based payment platform that enables instant cross-border transactions with minimal fees.",
        closingDate: new Date("2024-10-31"),
        totalInvestment: 1000000,
        percentageDilution: 25,
        documents: "https://example.com/docs/fintech",
      },
    ]);

    // Create investor profile with references to startups
    const investor = await Investor.create({
      user: investorUser._id,
      firstName: "John",
      lastName: "Doe",
      investments: [startups[0]._id, startups[1]._id],
    });

    console.log("\nTest data created successfully!");
    console.log("\nInvestor Account:");
    console.log("Email:", investorUser.email);
    console.log("Password: test123");

    console.log("\nStartup Accounts:");
    startups.forEach((startup, index) => {
      console.log(`\nStartup ${index + 1}:`);
      console.log("Email:", `startup${index + 1}@example.com`);
      console.log("Title:", startup.title);
    });
  } catch (error) {
    console.error("Error seeding database:", error.message);
    if (error.stack) console.error(error.stack);
  } finally {
    if (mongoose.connection.readyState === 1) {
      await mongoose.connection.close();
    }
  }
}

seedDatabase();
