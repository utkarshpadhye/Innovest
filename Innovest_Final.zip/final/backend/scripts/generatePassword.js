const bcrypt = require("bcryptjs");

async function generateHash() {
  const password = "test123"; // This will be the password you can use to login
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  console.log("Hashed password:", hash);
}

generateHash();
