class ResponseHandler {
  constructor(res) {
    this.res = res;
  }

  success(data, message = "Success", statusCode = 200) {
    return this.res.status(statusCode).json({
      status: "success",
      message,
      data,
    });
  }

  error(message, statusCode = 400) {
    return this.res.status(statusCode).json({
      status: "error",
      message,
    });
  }

  created(data, message = "Resource created successfully") {
    return this.success(data, message, 201);
  }

  noContent() {
    return this.res.status(204).json();
  }

  notFound(message = "Resource not found") {
    return this.error(message, 404);
  }

  unauthorized(message = "Unauthorized") {
    return this.error(message, 401);
  }

  forbidden(message = "Forbidden") {
    return this.error(message, 403);
  }
}

module.exports = (res) => new ResponseHandler(res);
