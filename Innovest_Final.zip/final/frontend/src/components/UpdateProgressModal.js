import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "../styles/modal.css";

const UpdateProgressModal = ({
  isOpen,
  onClose,
  currentProgress,
  totalInvestment,
  onUpdate,
}) => {
  const [amount, setAmount] = useState(currentProgress);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (amount < 0) {
      setError("Amount cannot be negative");
      return;
    }
    if (amount > totalInvestment) {
      setError("Amount cannot exceed total investment required");
      return;
    }
    onUpdate(amount);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="modal-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="modal-content"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
          >
            <h3>Update Progress</h3>
            <div className="form-group">
              <label>Investment Raised ($)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => {
                  setAmount(Number(e.target.value));
                  setError("");
                }}
                min="0"
                max={totalInvestment}
                className={error ? "error" : ""}
              />
              {error && <div className="error-message">{error}</div>}
              <div className="progress-info">
                <span>Total Required: ${totalInvestment.toLocaleString()}</span>
              </div>
            </div>
            <div className="modal-actions">
              <button className="secondary-button" onClick={onClose}>
                Cancel
              </button>
              <button className="primary-button" onClick={handleSubmit}>
                Update
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default UpdateProgressModal;
