import React, { useState } from "react";
import PaymentModal from "./PaymentModal";

const InvestButton = ({ startup }) => {
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const handleInvestmentSuccess = async () => {
    // Here you can implement the logic to update the database
    alert("Investment successful! This is a demo payment.");
    window.location.reload();
  };

  return (
    <>
      <button
        className="invest-button"
        onClick={() => setShowPaymentModal(true)}
      >
        Invest Now
      </button>

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        startupDetails={{
          title: startup.title,
          investmentAmount: startup.totalInvestment,
          equity: startup.percentageDilution,
        }}
        onSuccess={handleInvestmentSuccess}
      />
    </>
  );
};

export default InvestButton;
