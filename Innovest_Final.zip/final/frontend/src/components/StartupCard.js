import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import PaymentModal from "./PaymentModal";

const StartupCard = ({ startup }) => {
  const navigate = useNavigate();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleInvestClick = () => {
    setShowPaymentModal(true);
  };

  const handleInvestmentSuccess = async () => {
    try {
      setIsProcessing(true);
      const token = localStorage.getItem("userToken");
      await axios.post(
        `http://localhost:5000/api/startup/${startup._id}/invest`,
        {
          amount: startup.totalInvestment,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert("Investment successful!");
      window.location.reload();
    } catch (error) {
      console.error("Error updating investment:", error);
      alert("Error updating investment record");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleViewDocument = async () => {
    try {
      const token = localStorage.getItem("userToken");
      const response = await axios.get(
        `http://localhost:5000/api/startup/${startup._id}/document`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          responseType: "blob",
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `${startup.title}-documents.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Error downloading document:", error);
      alert("Error downloading document. Please try again later.");
    }
  };

  return (
    <div className="startup-card">
      <h3>{startup.title}</h3>
      <div className="status-wrapper">
        <span className="status-badge">Active</span>
      </div>
      <p className="startup-description">{startup.description}</p>

      <div className="startup-details">
        <div className="detail-item">
          <span className="detail-label">Investment Required</span>
          <strong className="detail-value">
            ${startup.totalInvestment.toLocaleString()}
          </strong>
        </div>
        <div className="detail-item">
          <span className="detail-label">Equity Offered</span>
          <strong className="detail-value">
            {startup.percentageDilution}%
          </strong>
        </div>
        <div className="detail-item">
          <span className="detail-label">Closing Date</span>
          <strong className="detail-value">
            {new Date(startup.closingDate).toLocaleDateString()}
          </strong>
        </div>
      </div>

      <div className="card-actions">
        <button onClick={handleViewDocument} className="view-documents-button">
          View Documents
        </button>
        <button
          onClick={handleInvestClick}
          className="view-documents-button"
          style={{ marginTop: "8px" }}
        >
          Invest Now
        </button>

        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          startupDetails={{
            title: startup.title,
            investmentAmount: startup.totalInvestment,
            equity: startup.percentageDilution,
          }}
          onSuccess={handleInvestmentSuccess}
        />
      </div>
    </div>
  );
};

export default StartupCard;
