import React from "react";
import { motion } from "framer-motion";

const StepProgress = ({ currentStep }) => {
  const steps = [
    { number: 1, title: "Basic Info" },
    { number: 2, title: "Description" },
    { number: 3, title: "Investment Details" },
  ];

  return (
    <div className="steps-progress">
      {steps.map((step, index) => (
        <div key={step.number} className="step-item">
          <motion.div
            className={`step-circle ${
              currentStep >= step.number ? "active" : ""
            }`}
            initial={false}
            animate={{
              scale: currentStep === step.number ? 1.1 : 1,
              transition: { duration: 0.3 },
            }}
          >
            {currentStep > step.number ? "✓" : step.number}
          </motion.div>
          <div className="step-text">{step.title}</div>
          {index < steps.length - 1 && (
            <motion.div
              className={`step-line ${
                currentStep > step.number ? "active" : ""
              }`}
              initial={{ scaleX: 0 }}
              animate={{ scaleX: currentStep > step.number ? 1 : 0 }}
              transition={{ duration: 0.3 }}
            />
          )}
        </div>
      ))}
    </div>
  );
};

export default StepProgress;
