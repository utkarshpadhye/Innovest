import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import PageTransition from "../transitions/PageTransition";
import LoadingSpinner from "../common/LoadingSpinner";
import "../../styles/investments.css";

const MyInvestments = () => {
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchInvestments = async () => {
      try {
        const token = localStorage.getItem("userToken");
        const response = await axios.get(
          "http://localhost:5000/api/investor/profile",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setInvestments(response.data.investments || []);
        setLoading(false);
      } catch (err) {
        setError("Error fetching investments");
        setLoading(false);
      }
    };

    fetchInvestments();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <PageTransition>
      <div className="investments-container">
        <h1>My Investment Portfolio</h1>

        {investments.length === 0 ? (
          <motion.div
            className="empty-state"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h3>No investments yet</h3>
            <p>Start exploring startups to begin your investment journey</p>
            <button
              className="primary-button"
              onClick={() => (window.location.href = "/investor")}
            >
              Explore Startups
            </button>
          </motion.div>
        ) : (
          <div className="investments-grid">
            {investments.map((investment, index) => (
              <motion.div
                key={investment._id}
                className="investment-card"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="investment-header">
                  <h3>{investment.title}</h3>
                  <span className="status-badge">Active</span>
                </div>

                <p className="investment-description">
                  {investment.description}
                </p>

                <div className="investment-details">
                  <div className="detail-row">
                    <span className="detail-label">Investment Amount</span>
                    <span className="detail-value">
                      ${investment.totalInvestment?.toLocaleString()}
                    </span>
                  </div>
                  <div className="detail-row">
                    <span className="detail-label">Equity</span>
                    <span className="detail-value">
                      {investment.percentageDilution}%
                    </span>
                  </div>
                  <div className="detail-row">
                    <span className="detail-label">Investment Date</span>
                    <span className="detail-value">
                      {new Date(investment.closingDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="investment-actions">
                  <button className="view-docs-button">View Documents</button>
                  <button className="contact-startup-button">
                    Contact Startup
                  </button>
                </div>

                <div className="investment-metrics">
                  <div className="metric">
                    <span className="metric-value">+15%</span>
                    <span className="metric-label">Growth</span>
                  </div>
                  <div className="metric">
                    <span className="metric-value">A+</span>
                    <span className="metric-label">Rating</span>
                  </div>
                  <div className="metric">
                    <span className="metric-value">High</span>
                    <span className="metric-label">Potential</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  );
};

export default MyInvestments;
