import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import "../../styles/sidebar.css";

const Sidebar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>InnoVest</h2>
      </div>
      <nav>
        {user?.role === "Investor" ? (
          <>
            <Link
              to="/investor"
              className={`nav-link ${
                location.pathname === "/investor" ? "active" : ""
              }`}
            >
              Dashboard
            </Link>
            <Link
              to="/investments"
              className={`nav-link ${
                location.pathname === "/investments" ? "active" : ""
              }`}
            >
              My Investments
            </Link>
          </>
        ) : (
          <>
            <Link
              to="/startup"
              className={`nav-link ${
                location.pathname === "/startup" ? "active" : ""
              }`}
            >
              Dashboard
            </Link>
            <Link
              to="/startup/profile"
              className={`nav-link ${
                location.pathname === "/startup/profile" ? "active" : ""
              }`}
            >
              Company Profile
            </Link>
          </>
        )}
        <Link
          to="/profile"
          className={`nav-link ${
            location.pathname === "/profile" ? "active" : ""
          }`}
        >
          My Profile
        </Link>
        <button onClick={handleLogout} className="logout">
          Logout
        </button>
      </nav>
    </div>
  );
};

export default Sidebar;
