import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import PageTransition from "../transitions/PageTransition";
import LoadingSpinner from "../common/LoadingSpinner";
import "../../styles/myProfile.css";

const MyProfile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("userToken");
        const role = localStorage.getItem("userRole");
        const baseUrl =
          role === "Investor"
            ? "http://localhost:5000/api/investor/profile"
            : "http://localhost:5000/api/startup/profile";

        const response = await axios.get(baseUrl, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setProfile(response.data);
        setLoading(false);
      } catch (err) {
        setError("Error fetching profile. Please try again later.");
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="error-message">{error}</div>;
  if (!profile) return null;

  return (
    <PageTransition>
      <div className="profile-container">
        <motion.div
          className="profile-card"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="profile-header">
            <h2>My Profile</h2>
            <button
              className="edit-button"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? "Cancel" : "Edit Profile"}
            </button>
          </div>

          <div className="profile-content">
            <div className="profile-section">
              <div className="profile-field">
                <span className="field-label">Name</span>
                <span className="field-value">
                  {profile.firstName} {profile.lastName}
                </span>
              </div>

              <div className="profile-field">
                <span className="field-label">Email</span>
                <span className="field-value">{profile.email}</span>
              </div>

              <div className="profile-field">
                <span className="field-label">Role</span>
                <span className="role-badge">
                  {localStorage.getItem("userRole")}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </PageTransition>
  );
};

export default MyProfile;
