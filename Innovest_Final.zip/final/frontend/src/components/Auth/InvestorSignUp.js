import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import {
  validateEmail,
  validatePassword,
  validateInvestorInput,
} from "../../utils/validation";
import SuccessModal from "../common/SuccessModal";
import LoadingSpinner from "../common/LoadingSpinner";
import "../../styles/auth.css";

const InvestorSignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const validateForm = () => {
    const newErrors = {};

    // Validate email
    if (!validateEmail(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    // Validate password
    const passwordValidation = validatePassword(formData.password);
    if (!passwordValidation.isValid) {
      newErrors.password = passwordValidation.errors[0];
    }

    // Validate investor fields
    const investorValidation = validateInvestorInput(formData);
    if (!investorValidation.isValid) {
      Object.assign(newErrors, investorValidation.errors);
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      await axios.post(
        "http://localhost:5000/api/auth/register/investor",
        formData
      );
      setShowSuccess(true);
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (err) {
      setErrors({
        submit: err.response?.data?.message || "Failed to create account",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const nextStep = () => {
    if (currentStep === 1 && validateFirstStep()) {
      setCurrentStep(2);
    }
  };

  const validateFirstStep = () => {
    const stepErrors = {};
    if (!formData.firstName.trim())
      stepErrors.firstName = "First name is required";
    if (!formData.lastName.trim())
      stepErrors.lastName = "Last name is required";
    setErrors(stepErrors);
    return Object.keys(stepErrors).length === 0;
  };

  return (
    <div className="auth-container">
      <motion.div
        className="auth-form-container"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
      >
        <button className="back-button" onClick={() => navigate("/signup")}>
          ← Back
        </button>

        <motion.div className="progress-bar">
          <div
            className={`progress-step ${currentStep >= 1 ? "active" : ""}`}
            onClick={() => setCurrentStep(1)}
          >
            1. Personal Info
          </div>
          <div
            className={`progress-step ${currentStep >= 2 ? "active" : ""}`}
            onClick={() => currentStep === 2 && setCurrentStep(2)}
          >
            2. Account Setup
          </div>
        </motion.div>

        <h2>Create Investor Account</h2>
        <p className="auth-subtitle">Start your investment journey</p>

        {errors.submit && (
          <motion.div
            className="error-message"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {errors.submit}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <AnimatePresence mode="wait">
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <div className="form-group">
                  <label htmlFor="firstName">First Name</label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className={errors.firstName ? "error" : ""}
                  />
                  {errors.firstName && (
                    <span className="error-text">{errors.firstName}</span>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="lastName">Last Name</label>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className={errors.lastName ? "error" : ""}
                  />
                  {errors.lastName && (
                    <span className="error-text">{errors.lastName}</span>
                  )}
                </div>

                <button
                  type="button"
                  className="next-button"
                  onClick={nextStep}
                >
                  Next →
                </button>
              </motion.div>
            )}

            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="form-group">
                  <label htmlFor="email">Email Address</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={errors.email ? "error" : ""}
                  />
                  {errors.email && (
                    <span className="error-text">{errors.email}</span>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className={errors.password ? "error" : ""}
                  />
                  {errors.password && (
                    <span className="error-text">{errors.password}</span>
                  )}
                </div>

                <button
                  type="submit"
                  className="submit-button"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <LoadingSpinner size="small" />
                  ) : (
                    "Create Account"
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </form>

        <div className="auth-footer">
          Already have an account?{" "}
          <button onClick={() => navigate("/login")}>Sign in</button>
        </div>
      </motion.div>

      <AnimatePresence>
        {showSuccess && (
          <SuccessModal
            message="Account created successfully! Redirecting to login..."
            onClose={() => setShowSuccess(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default InvestorSignUp;
