import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const ProtectedRoute = ({ children, requiredRole }) => {
  const { user } = useAuth();

  if (!user?.token) {
    return <Navigate to="/login" />;
  }

  if (requiredRole && user.role !== requiredRole) {
    // Redirect to appropriate dashboard if user tries to access wrong role's pages
    return (
      <Navigate to={user.role === "Investor" ? "/investor" : "/startup"} />
    );
  }

  return children;
};

export default ProtectedRoute;
