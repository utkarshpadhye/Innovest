import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import DatePicker from "react-datepicker";
import {
  validateEmail,
  validatePassword,
  validateInvestmentAmount,
  validateEquityPercentage,
  validateClosingDate,
} from "../../utils/validation";
import SuccessModal from "../common/SuccessModal";
import LoadingSpinner from "../common/LoadingSpinner";
import "react-datepicker/dist/react-datepicker.css";
import "../../styles/auth.css";
import "../../styles/datepicker.css";

const StepProgress = ({ currentStep }) => {
  const steps = [
    { number: 1, title: "Basic Info" },
    { number: 2, title: "Description" },
    { number: 3, title: "Investment Details" },
  ];

  return (
    <div className="steps-progress">
      {steps.map((step, index) => (
        <div key={step.number} className="step-item">
          <motion.div
            className={`step-circle ${
              currentStep >= step.number ? "active" : ""
            }`}
            initial={false}
            animate={{
              scale: currentStep === step.number ? 1.1 : 1,
              transition: { duration: 0.3 },
            }}
          >
            {currentStep > step.number ? "✓" : step.number}
          </motion.div>
          <div className="step-text">{step.title}</div>
          {index < steps.length - 1 && (
            <motion.div
              className={`step-line ${
                currentStep > step.number ? "active" : ""
              }`}
              initial={{ scaleX: 0 }}
              animate={{ scaleX: currentStep > step.number ? 1 : 0 }}
              transition={{ duration: 0.3 }}
            />
          )}
        </div>
      ))}
    </div>
  );
};

const StartupSignUp = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    startupName: "",
    email: "",
    password: "",
    description: "",
    totalInvestment: "",
    percentageDilution: "",
    closingDate: new Date(),
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const validateFirstStep = () => {
    const stepErrors = {};
    if (!formData.startupName.trim()) {
      stepErrors.startupName = "Startup name is required";
    }
    if (!validateEmail(formData.email)) {
      stepErrors.email = "Please enter a valid email";
    }
    const passwordValidation = validatePassword(formData.password);
    if (!passwordValidation.isValid) {
      stepErrors.password = passwordValidation.errors[0];
    }
    setErrors(stepErrors);
    return Object.keys(stepErrors).length === 0;
  };

  const validateSecondStep = () => {
    const stepErrors = {};
    if (!formData.description.trim()) {
      stepErrors.description = "Description is required";
    } else if (formData.description.length < 100) {
      stepErrors.description = "Description should be at least 100 characters";
    }
    setErrors(stepErrors);
    return Object.keys(stepErrors).length === 0;
  };

  const validateThirdStep = () => {
    const stepErrors = {};
    const investmentError = validateInvestmentAmount(formData.totalInvestment);
    const equityError = validateEquityPercentage(formData.percentageDilution);
    const dateError = validateClosingDate(formData.closingDate);

    if (investmentError) stepErrors.totalInvestment = investmentError;
    if (equityError) stepErrors.percentageDilution = equityError;
    if (dateError) stepErrors.closingDate = dateError;

    setErrors(stepErrors);
    return Object.keys(stepErrors).length === 0;
  };

  const nextStep = () => {
    if (currentStep === 1 && validateFirstStep()) {
      setCurrentStep(2);
    } else if (currentStep === 2 && validateSecondStep()) {
      setCurrentStep(3);
    }
  };

  const prevStep = () => {
    setCurrentStep((prev) => Math.max(1, prev - 1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateThirdStep()) return;

    setIsLoading(true);
    try {
      const formattedData = {
        ...formData,
        totalInvestment: Number(formData.totalInvestment),
        percentageDilution: Number(formData.percentageDilution),
      };

      await axios.post(
        "http://localhost:5000/api/auth/register/startup",
        formattedData
      );
      setShowSuccess(true);
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (err) {
      setErrors({
        submit: err.response?.data?.message || "Failed to create account",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderBasicInfo = () => (
    <motion.div
      key="step1"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="form-step"
    >
      <div className="form-group">
        <label htmlFor="startupName">Startup Name</label>
        <input
          type="text"
          id="startupName"
          name="startupName"
          value={formData.startupName}
          onChange={handleInputChange}
          className={errors.startupName ? "error" : ""}
          placeholder="Enter your startup's name"
        />
        {errors.startupName && (
          <span className="error-text">{errors.startupName}</span>
        )}
      </div>

      <div className="form-group">
        <label htmlFor="email">Official Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          className={errors.email ? "error" : ""}
          placeholder="Enter your business email"
        />
        {errors.email && <span className="error-text">{errors.email}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          className={errors.password ? "error" : ""}
          placeholder="Create a secure password"
        />
        {errors.password && (
          <span className="error-text">{errors.password}</span>
        )}
        <span className="helper-text">
          Password must be at least 8 characters long with uppercase, lowercase,
          number and special character
        </span>
      </div>

      <button type="button" className="next-button" onClick={nextStep}>
        Next →
      </button>
    </motion.div>
  );

  const renderDescription = () => (
    <motion.div
      key="step2"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="form-step"
    >
      <div className="form-group">
        <label htmlFor="description">Tell us about your startup</label>
        <textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          className={errors.description ? "error" : ""}
          rows="6"
          placeholder="What problem are you solving? What's your unique solution? What's your market opportunity?"
        />
        {errors.description && (
          <span className="error-text">{errors.description}</span>
        )}
        <span className="helper-text">Minimum 100 characters required</span>
      </div>

      <div className="button-group">
        <button type="button" className="back-button" onClick={prevStep}>
          ← Back
        </button>
        <button type="button" className="next-button" onClick={nextStep}>
          Next →
        </button>
      </div>
    </motion.div>
  );

  const renderInvestmentDetails = () => (
    <motion.div
      key="step3"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="form-step"
    >
      <div className="form-group">
        <label htmlFor="totalInvestment">Investment Required</label>
        <div className="input-with-prefix">
          <span className="input-prefix">$</span>
          <input
            type="number"
            id="totalInvestment"
            name="totalInvestment"
            value={formData.totalInvestment}
            onChange={handleInputChange}
            className={errors.totalInvestment ? "error" : ""}
            min="10000"
            step="1000"
            placeholder="Minimum $10,000"
          />
        </div>
        {errors.totalInvestment && (
          <span className="error-text">{errors.totalInvestment}</span>
        )}
        <span className="helper-text">
          Enter amount between $10,000 and $100M
        </span>
      </div>

      <div className="form-group">
        <label htmlFor="percentageDilution">Equity Offering</label>
        <div className="input-with-suffix">
          <input
            type="number"
            id="percentageDilution"
            name="percentageDilution"
            value={formData.percentageDilution}
            onChange={handleInputChange}
            className={errors.percentageDilution ? "error" : ""}
            min="0"
            max="100"
            step="0.1"
            placeholder="Enter percentage"
          />
          <span className="input-suffix">%</span>
        </div>
        {errors.percentageDilution && (
          <span className="error-text">{errors.percentageDilution}</span>
        )}
      </div>

      <div className="form-group">
        <label>Round Closing Date</label>
        <DatePicker
          selected={formData.closingDate}
          onChange={(date) =>
            setFormData((prev) => ({ ...prev, closingDate: date }))
          }
          minDate={new Date()}
          dateFormat="MMMM d, yyyy"
          className={errors.closingDate ? "error" : ""}
          placeholderText="Select closing date"
        />
        {errors.closingDate && (
          <span className="error-text">{errors.closingDate}</span>
        )}
        <span className="helper-text">Must be at least 7 days from today</span>
      </div>

      <div className="button-group">
        <button type="button" className="back-button" onClick={prevStep}>
          ← Back
        </button>
        <button type="submit" className="submit-button" disabled={isLoading}>
          {isLoading ? <LoadingSpinner size="small" /> : "Create Account"}
        </button>
      </div>
    </motion.div>
  );

  return (
    <div className="auth-container">
      <motion.div
        className="auth-form-container"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
      >
        <div className="auth-header">
          <button className="back-button" onClick={() => navigate("/signup")}>
            ← Back
          </button>
          <StepProgress currentStep={currentStep} />
        </div>

        <h2>Register Your Startup</h2>
        <p className="auth-subtitle">Connect with potential investors</p>

        {errors.submit && (
          <motion.div
            className="error-message"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {errors.submit}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <AnimatePresence mode="wait">
            {currentStep === 1 && renderBasicInfo()}
            {currentStep === 2 && renderDescription()}
            {currentStep === 3 && renderInvestmentDetails()}
          </AnimatePresence>
        </form>
      </motion.div>

      <AnimatePresence>
        {showSuccess && (
          <SuccessModal
            message="Startup registered successfully! Redirecting to login..."
            onClose={() => setShowSuccess(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default StartupSignUp;
