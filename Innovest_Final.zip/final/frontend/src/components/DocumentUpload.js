import React, { useState } from "react";
import axios from "axios";

const DocumentUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/pdf") {
      setSelectedFile(file);
      setError(null);
    } else {
      setError("Please select a PDF file");
      setSelectedFile(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError("Please select a file first");
      return;
    }

    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append("document", selectedFile);

    try {
      const token = localStorage.getItem("userToken");
      await axios.post(
        "http://localhost:5000/api/startup/upload-document",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setSuccess(true);
      setSelectedFile(null);
      // Reset file input
      const fileInput = document.querySelector('input[type="file"]');
      if (fileInput) fileInput.value = "";

      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    } catch (err) {
      console.error("Upload error:", err);
      setError(
        err.response?.data?.message ||
          "Failed to upload document. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="document-upload">
      <div className="upload-container">
        <input
          type="file"
          accept=".pdf"
          onChange={handleFileSelect}
          className={error ? "error" : ""}
          disabled={loading}
        />
        {selectedFile && (
          <p className="selected-file">Selected: {selectedFile.name}</p>
        )}
        <button
          onClick={handleUpload}
          disabled={!selectedFile || loading}
          className="upload-button"
        >
          {loading ? "Uploading..." : "Upload Document"}
        </button>
      </div>

      {error && <p className="error-message">{error}</p>}
      {success && (
        <p className="success-message">Document uploaded successfully!</p>
      )}
    </div>
  );
};

export default DocumentUpload;
