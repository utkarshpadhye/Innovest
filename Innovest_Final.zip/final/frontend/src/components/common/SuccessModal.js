import React from "react";
import { motion } from "framer-motion";
import "../../styles/modal.css";

const SuccessModal = ({ message, onClose }) => {
  return (
    <motion.div
      className="modal-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="modal-content success"
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.5, opacity: 0 }}
      >
        <div className="success-icon">✓</div>
        <h3>{message}</h3>
      </motion.div>
    </motion.div>
  );
};

export default SuccessModal;
