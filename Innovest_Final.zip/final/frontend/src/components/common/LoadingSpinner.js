import React from "react";
import "../../styles/loading.css";

const LoadingSpinner = ({ size = "medium" }) => {
  return (
    <div className={`spinner-container ${size}`}>
      <div className="spinner" />
    </div>
  );
};

export default LoadingSpinner;
