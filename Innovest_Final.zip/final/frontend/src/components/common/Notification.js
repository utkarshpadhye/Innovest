import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import "../../styles/notification.css";

const Notification = ({
  message,
  type = "success",
  onClose,
  duration = 3000,
}) => {
  React.useEffect(() => {
    if (duration) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  return (
    <AnimatePresence>
      <motion.div
        className={`notification ${type}`}
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50 }}
        transition={{ type: "spring", stiffness: 500, damping: 40 }}
      >
        <div className="notification-icon">
          {type === "success" ? "✓" : type === "error" ? "✕" : "ℹ"}
        </div>
        <div className="notification-content">
          <p>{message}</p>
        </div>
        <button className="notification-close" onClick={onClose}>
          ×
        </button>
      </motion.div>
    </AnimatePresence>
  );
};

export default Notification;
