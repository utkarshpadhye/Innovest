import React from "react";
import { Link } from "react-router-dom";

const Sidebar = ({ role }) => (
  <div className="sidebar">
    <ul>
      {role === "Investor" ? (
        <>
          <li>
            <Link to="/investor">Explore Startups</Link>
          </li>
          <li>
            <Link to="/investor/investments">My Investments</Link>
          </li>
        </>
      ) : (
        <>
          <li>
            <Link to="/startup">My Startup</Link>
          </li>
          <li>
            <Link to="/startup/overview">Investment Overview</Link>
          </li>
        </>
      )}
      <li>
        <Link to="/profile">My Profile</Link>
      </li>
      <li>
        <Link to="/login">Logout</Link>
      </li>
    </ul>
  </div>
);

export default Sidebar;
