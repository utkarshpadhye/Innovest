import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "../styles/modal.css";

const PaymentModal = ({ isOpen, onClose, startupDetails, onSuccess }) => {
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handlePayment = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Simulate payment processing
    setTimeout(() => {
      setLoading(false);
      onSuccess();
      onClose();
    }, 2000);
  };

  return (
    <AnimatePresence>
      <motion.div
        className="modal-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="modal-content payment-modal"
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
        >
          <div className="modal-header">
            <h2>Invest in {startupDetails.title}</h2>
            <button className="close-button" onClick={onClose}>
              &times;
            </button>
          </div>

          <div className="payment-details">
            <div className="amount-card">
              <div className="amount-row">
                <span>Investment Amount</span>
                <span className="amount">
                  ${startupDetails.investmentAmount.toLocaleString()}
                </span>
              </div>
              <div className="amount-row">
                <span>Equity</span>
                <span>{startupDetails.equity}%</span>
              </div>
            </div>

            {step === 1 && (
              <div className="payment-methods">
                <h3>Select Payment Method</h3>
                <div className="method-options">
                  <button
                    className={`method-button ${
                      paymentMethod === "card" ? "selected" : ""
                    }`}
                    onClick={() => setPaymentMethod("card")}
                  >
                    Credit/Debit Card
                  </button>
                  <button
                    className={`method-button ${
                      paymentMethod === "upi" ? "selected" : ""
                    }`}
                    onClick={() => setPaymentMethod("upi")}
                  >
                    UPI
                  </button>
                  <button
                    className={`method-button ${
                      paymentMethod === "netbanking" ? "selected" : ""
                    }`}
                    onClick={() => setPaymentMethod("netbanking")}
                  >
                    Net Banking
                  </button>
                </div>
                {paymentMethod && (
                  <button
                    className="continue-button"
                    onClick={() => setStep(2)}
                  >
                    Continue
                  </button>
                )}
              </div>
            )}

            {step === 2 && (
              <form onSubmit={handlePayment} className="payment-form">
                <h3>Enter Payment Details</h3>
                {paymentMethod === "card" && (
                  <>
                    <div className="form-group">
                      <label>Card Number</label>
                      <input
                        type="text"
                        placeholder="1234 5678 9012 3456"
                        maxLength="16"
                        required
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                      />
                    </div>
                    <div className="form-row">
                      <div className="form-group">
                        <label>Expiry Date</label>
                        <input
                          type="text"
                          placeholder="MM/YY"
                          maxLength="5"
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label>CVV</label>
                        <input
                          type="text"
                          placeholder="123"
                          maxLength="3"
                          required
                        />
                      </div>
                    </div>
                  </>
                )}

                {paymentMethod === "upi" && (
                  <div className="form-group">
                    <label>UPI ID</label>
                    <input type="text" placeholder="yourname@upi" required />
                  </div>
                )}

                {paymentMethod === "netbanking" && (
                  <div className="form-group">
                    <label>Select Bank</label>
                    <select required>
                      <option value="">Select a bank</option>
                      <option value="sbi">State Bank of India</option>
                      <option value="hdfc">HDFC Bank</option>
                      <option value="icici">ICICI Bank</option>
                      <option value="axis">Axis Bank</option>
                    </select>
                  </div>
                )}

                <div className="button-group">
                  <button
                    type="button"
                    className="back-button"
                    onClick={() => setStep(1)}
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="pay-button"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="loading-spinner"></span>
                    ) : (
                      `Pay $${startupDetails.investmentAmount.toLocaleString()}`
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default PaymentModal;
