import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import PageTransition from "../components/transitions/PageTransition";
import "../styles/home.css";

const Home = () => {
  return (
    <PageTransition>
      <div className="home-container">
        <div className="hero-section">
          <motion.div
            className="hero-content"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1>Welcome to InnoVest</h1>
            <p className="hero-subtitle">
              Connecting Visionary Startups with Strategic Investors
            </p>

            <div className="cta-buttons">
              <Link to="/signup" className="cta-button primary">
                Get Started
              </Link>
              <Link to="/login" className="cta-button secondary">
                Sign In
              </Link>
            </div>
          </motion.div>

          <motion.div
            className="hero-stats"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <div className="stat-item">
              <h3>50+</h3>
              <p>Startups</p>
            </div>
            <div className="stat-item">
              <h3>$50M+</h3>
              <p>Investments</p>
            </div>
            <div className="stat-item">
              <h3>10+</h3>
              <p>Investors</p>
            </div>
          </motion.div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Home;
