import React, { useEffect, useState } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import LoadingSpinner from "../components/common/LoadingSpinner";
import UpdateProgressModal from "../components/UpdateProgressModal";
import "../styles/startupPage.css";

const StartupPage = () => {
  const [startupData, setStartupData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);

  useEffect(() => {
    fetchStartupData();
  }, []);

  const fetchStartupData = async () => {
    try {
      const token = localStorage.getItem("userToken");
      const response = await axios.get(
        "http://localhost:5000/api/startup/profile",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setStartupData(response.data);
      setLoading(false);
    } catch (err) {
      console.error("Error fetching startup data:", err);
      setError(
        err.response?.data?.message ||
          "Error fetching startup data. Please try again later."
      );
      setLoading(false);
    }
  };

  const handleUpdateDescription = async (newDescription) => {
    try {
      const token = localStorage.getItem("userToken");
      await axios.post(
        "http://localhost:5000/api/startup/update-description",
        { description: newDescription },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      fetchStartupData();
      setIsEditing(false);
    } catch (err) {
      console.error("Error updating description:", err);
      setError("Failed to update description. Please try again.");
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("document", file);

    try {
      const token = localStorage.getItem("userToken");
      await axios.post(
        "http://localhost:5000/api/startup/upload-document",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      fetchStartupData();
    } catch (err) {
      console.error("Error uploading document:", err);
      setError("Failed to upload document. Please try again.");
    }
  };

  const handleUpdateProgress = async (newAmount) => {
    try {
      const token = localStorage.getItem("userToken");
      await axios.post(
        "http://localhost:5000/api/startup/update-progress",
        { fundingRaised: newAmount },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      fetchStartupData();
    } catch (err) {
      console.error("Error updating progress:", err);
      setError("Failed to update progress. Please try again.");
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="error-message">{error}</div>;
  if (!startupData) return null;

  const progressPercentage =
    (startupData.fundingRaised / startupData.totalInvestment) * 100;

  return (
    <div className="startup-page">
      <div className="page-header">
        <h1>{startupData.title || "InnoVest"}</h1>
        <span className="status-badge">Active</span>
      </div>

      <div className="content-layout">
        {/* Description Card */}
        <div className="description-card">
          <div className="card-header">
            <h2>About</h2>
            {isEditing ? (
              <button
                className="edit-button"
                onClick={() => {
                  const textarea = document.querySelector(
                    ".description-editor"
                  );
                  handleUpdateDescription(textarea.value);
                }}
              >
                Save
              </button>
            ) : (
              <button
                className="edit-button"
                onClick={() => setIsEditing(true)}
              >
                Edit
              </button>
            )}
          </div>
          <div style={{ maxWidth: "100%" }}>
            {" "}
            {/* Add this wrapper */}
            {isEditing ? (
              <textarea
                className="description-editor"
                defaultValue={startupData.description}
                rows={6}
              />
            ) : (
              <p className="description">{startupData.description}</p>
            )}
          </div>
        </div>

        {/* Cards Row */}
        <div className="cards-row">
          {/* Investment Details Card */}
          <div className="info-card">
            <h2>Investment Details</h2>
            <div className="detail-row">
              <span className="detail-label">Investment Required</span>
              <span className="detail-value">
                ${startupData.totalInvestment?.toLocaleString()}
              </span>
            </div>
            <div className="detail-row">
              <span className="detail-label">Equity Offered</span>
              <span className="detail-value">
                {startupData.percentageDilution}%
              </span>
            </div>
            <div className="detail-row">
              <span className="detail-label">Round Closing</span>
              <span className="detail-value">
                {new Date(startupData.closingDate).toLocaleDateString()}
              </span>
            </div>
          </div>

          {/* Progress Card */}
          <div className="info-card">
            <h2>Progress</h2>
            <div className="detail-label">Investment Raised</div>
            <div className="progress-bar">
              <motion.div
                className="progress-fill"
                initial={{ width: "0%" }}
                animate={{ width: `${progressPercentage}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <div className="progress-stats">
              <span>${startupData.fundingRaised?.toLocaleString() || "0"}</span>
              <span>${startupData.totalInvestment?.toLocaleString()}</span>
            </div>
            <button
              className="update-button"
              onClick={() => setIsProgressModalOpen(true)}
            >
              Update Progress
            </button>
          </div>

          {/* Documents Card */}
          <div className="info-card">
            <h2>Documents</h2>
            <div className="upload-section">
              {startupData.documents ? (
                <>
                  <a
                    href={startupData.documents}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="document-link"
                  >
                    View Documents
                  </a>
                  <label className="upload-button" htmlFor="document-upload">
                    Update
                  </label>
                </>
              ) : (
                <>
                  <p>No documents uploaded yet</p>
                  <label className="upload-button" htmlFor="document-upload">
                    Upload Documents
                  </label>
                </>
              )}
              <input
                type="file"
                id="document-upload"
                onChange={handleFileUpload}
                style={{ display: "none" }}
                accept=".pdf,.doc,.docx"
              />
            </div>
          </div>
        </div>
      </div>

      <UpdateProgressModal
        isOpen={isProgressModalOpen}
        onClose={() => setIsProgressModalOpen(false)}
        currentProgress={startupData.fundingRaised || 0}
        totalInvestment={startupData.totalInvestment}
        onUpdate={handleUpdateProgress}
      />
    </div>
  );
};

export default StartupPage;
