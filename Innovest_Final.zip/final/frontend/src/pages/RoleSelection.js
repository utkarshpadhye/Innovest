import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import "../styles/roleSelection.css";

const RoleSelection = () => {
  const navigate = useNavigate();

  return (
    <div className="role-selection-container">
      <motion.div
        className="role-selection-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h2>Join InnoVest</h2>
        <p>Choose how you want to join our platform</p>

        <div className="role-options">
          <motion.div
            className="role-option"
            whileHover={{ scale: 1.05 }}
            onClick={() => navigate("/signup/investor")}
          >
            <h3>Join as Investor</h3>
            <p>Discover and invest in promising startups</p>
          </motion.div>

          <motion.div
            className="role-option"
            whileHover={{ scale: 1.05 }}
            onClick={() => navigate("/signup/startup")}
          >
            <h3>Join as Startup</h3>
            <p>Raise funds and connect with potential investors</p>
          </motion.div>
        </div>

        <div className="auth-footer">
          Already have an account?{" "}
          <button onClick={() => navigate("/login")}>Sign in</button>
        </div>
      </motion.div>
    </div>
  );
};

export default RoleSelection;
