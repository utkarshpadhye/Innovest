import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import PageTransition from "../components/transitions/PageTransition";
import LoadingSpinner from "../components/common/LoadingSpinner";
import InvestButton from "../components/InvestButton";
import "../styles/startupCard.css";

const InvestorPage = () => {
  const [startups, setStartups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStartups = async () => {
      try {
        const token = localStorage.getItem("userToken");
        const response = await axios.get(
          "http://localhost:5000/api/investor/explore",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setStartups(response.data);
        setLoading(false);
      } catch (err) {
        setError("Error fetching startups");
        setLoading(false);
      }
    };

    fetchStartups();
  }, []);

  const handleViewDocument = async (startup) => {
    try {
      const token = localStorage.getItem("userToken");
      const response = await axios.get(
        `http://localhost:5000/api/startup/${startup._id}/document`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          responseType: "blob",
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `${startup.title}-documents.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Error downloading document:", error);
      alert("Error downloading document. Please try again later.");
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <PageTransition>
      <div className="container">
        <h1>Available Startups</h1>
        <div className="startup-grid">
          {startups.map((startup) => (
            <motion.div
              key={startup._id}
              className="startup-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h2 className="startup-title">{startup.title}</h2>
              <span className="status-badge">Active</span>
              <p className="startup-description">{startup.description}</p>
              <div className="startup-details">
                <div className="detail-item">
                  <span className="detail-label">Investment Required</span>
                  <span className="detail-value">
                    ${startup.totalInvestment.toLocaleString()}
                  </span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Equity Offered</span>
                  <span className="detail-value">
                    {startup.percentageDilution}%
                  </span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Closing Date</span>
                  <span className="detail-value">
                    {new Date(startup.closingDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <div className="card-actions">
                <button
                  className="view-docs-button"
                  onClick={() => handleViewDocument(startup)}
                >
                  View Documents
                </button>
                <InvestButton startup={startup} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </PageTransition>
  );
};

export default InvestorPage;
