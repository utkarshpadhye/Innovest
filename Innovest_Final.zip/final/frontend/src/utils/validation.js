// Email validation
export const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

// Password validation
export const validatePassword = (password) => {
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  const errors = [];
  if (!password) errors.push("Password is required");
  if (password.length < minLength)
    errors.push("Password must be at least 8 characters long");
  if (!hasUpperCase) errors.push("Include at least one uppercase letter");
  if (!hasLowerCase) errors.push("Include at least one lowercase letter");
  if (!hasNumbers) errors.push("Include at least one number");
  if (!hasSpecialChar) errors.push("Include at least one special character");

  return {
    isValid: errors.length === 0,
    errors,
  };
};

// Investment amount validation
export const validateInvestmentAmount = (amount) => {
  const numAmount = Number(amount);
  if (isNaN(numAmount) || amount === "") {
    return "Investment amount is required";
  }
  if (numAmount < 10000) {
    return "Minimum investment amount should be $10,000";
  }
  if (numAmount > 100000000) {
    return "Maximum investment amount should be $100M";
  }
  return "";
};

// Equity percentage validation
export const validateEquityPercentage = (percentage) => {
  const numPercentage = Number(percentage);
  if (isNaN(numPercentage) || percentage === "") {
    return "Equity percentage is required";
  }
  if (numPercentage <= 0 || numPercentage > 100) {
    return "Equity percentage should be between 0 and 100";
  }
  return "";
};

// Closing date validation
export const validateClosingDate = (date) => {
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 7); // Minimum 7 days from now
  if (date < minDate) {
    return "Closing date should be at least 7 days from today";
  }
  return "";
};

// Startup input validation
export const validateStartupInput = (data) => {
  const errors = {};

  if (!data.startupName?.trim()) {
    errors.startupName = "Startup name is required";
  }

  if (!data.description?.trim()) {
    errors.description = "Description is required";
  } else if (data.description.length < 100) {
    errors.description = "Description should be at least 100 characters";
  }

  const investmentError = validateInvestmentAmount(data.totalInvestment);
  if (investmentError) {
    errors.totalInvestment = investmentError;
  }

  const equityError = validateEquityPercentage(data.percentageDilution);
  if (equityError) {
    errors.percentageDilution = equityError;
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

// Investor input validation
export const validateInvestorInput = (data) => {
  const errors = {};

  if (!data.firstName?.trim()) {
    errors.firstName = "First name is required";
  }

  if (!data.lastName?.trim()) {
    errors.lastName = "Last name is required";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};
