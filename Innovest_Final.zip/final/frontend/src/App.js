import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Layout from "./components/Layout/Layout";
import Home from "./pages/Home";
import Login from "./components/Auth/Login";
import RoleSelection from "./pages/RoleSelection";
import InvestorSignUp from "./components/Auth/InvestorSignUp";
import StartupSignUp from "./components/Auth/StartupSignUp";
import InvestorPage from "./pages/InvestorPage";
import StartupPage from "./pages/StartupPage";
import MyInvestments from "./components/Investments/MyInvestments";
import MyProfile from "./components/Profile/MyProfile";
import ProtectedRoute from "./components/Auth/ProtectedRoute";
import "./styles/global.css";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<RoleSelection />} />
          <Route path="/signup/investor" element={<InvestorSignUp />} />
          <Route path="/signup/startup" element={<StartupSignUp />} />

          {/* Protected routes with Layout */}
          <Route
            path="/investor"
            element={
              <ProtectedRoute requiredRole="Investor">
                <Layout>
                  <InvestorPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/startup"
            element={
              <ProtectedRoute requiredRole="Startup">
                <Layout>
                  <StartupPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/investments"
            element={
              <ProtectedRoute requiredRole="Investor">
                <Layout>
                  <MyInvestments />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Layout>
                  <MyProfile />
                </Layout>
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
